#!/bin/bash
# hello - just a simple script for demonstration of chmod
#
# Kurt Schmidt
#
# 1/04
#
# Demonstrates: echo
#

clear
echo " "
echo " "
echo " "
echo "Hellooooo!  My name is $USER.  Have a good break?"
echo " "
echo " "
echo " "

